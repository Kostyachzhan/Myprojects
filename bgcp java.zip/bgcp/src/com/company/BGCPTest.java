package com.company;

import static org.junit.jupiter.api.Assertions.*;

class BGCPTest {

    @org.junit.jupiter.api.Test
    void initBGCP() {
    }

    @org.junit.jupiter.api.Test
    void initNumber() {
    }

    @org.junit.jupiter.api.Test
    void initDirectory() {
    }

    @org.junit.jupiter.api.Test
    void initResult() {
    }

    @org.junit.jupiter.api.Test
    void biggestCopy() {
    }
}