import sys
import bgcp
from bgcp import BGCP

if len(sys.argv) != 4:
    raise Exception('No parameters were passed')

bg = BGCP(sys.argv)
bg.biggestCopy()