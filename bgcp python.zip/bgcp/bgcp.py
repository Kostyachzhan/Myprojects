import sys
import os
import os.path
from os import path
from os import listdir
from os.path import isfile, join
from shutil import copyfile

class BGCP:
    def __init__(self, args):
        if len(args) != 4:
            raise Exception('No parameters were passed')

        self._directory = None
        self._number = None
        self._result = None

        self.initNumber(args[2])
        self.initDirectory(args[1])
        self.initResult(args[3])

    
    def initNumber(self, num):
        try:
            self._number = int(num)
        except ValueError:
            raise Exception('N parameter is invalid. Please use positive, non-zero number')
        if (self._number <= 0):
            raise Exception('N parameter is invalid. Please use positive, non-zero number')

    def initDirectory(self, dir):
        if (not path.exists(dir) or not path.isdir(dir)):
            raise Exception('D parameter is invalid. Directory does not exist')
        files = [f for f in listdir(dir) if isfile(join(dir, f))]
        if len(files) == 0:
            raise Exception('D parameter is invalid. Directory does not contains any files')
        if len(files) < self._number:
            raise Exception('D parameter is invalid. Directory does not contains enough files')
        self._directory = dir
    
    def initResult(self, res):
        if (not path.exists(res) or not path.isdir(res)):
            raise Exception('R parameter is invalid. Directory does not exist')
        self._result = res

    def byLength(arr):
        return arr[1]

    def biggestCopy(self):
        if(self._directory == None or self._number == None or self._result == None):
            raise Exception('Main parameters are uninitialized. Program halted.')
        files = [f for f in listdir(self._directory) if isfile(join(self._directory, f))]
        file_size = []
        for f in files:
            file_size.append((f, path.getsize(self._directory + "\\" + f)))
        file_size.sort(key=BGCP.byLength, reverse=True)

        print(file_size)

        results =[]
        for x in range(0, self._number):
            results.append(file_size[x])
        
        print(results)

        for f in results:
            if path.exists(self._result + "\\" + f[0]):
                raise Exception('File already exist. Program halted.')

        for f in results:
            copyfile(self._directory + "\\" + f[0], self._result + "\\" + f[0])