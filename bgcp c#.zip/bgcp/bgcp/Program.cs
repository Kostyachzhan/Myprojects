﻿using System;
using System.IO;
using System.Linq;

namespace bgcp
{
    class Program
    {
        static void Main(string[] args)
        {
            BGCP bGCP = new BGCP();
            bGCP.InitBGCP(args);
            bGCP.BiggestCopy();
        }
    }
}
