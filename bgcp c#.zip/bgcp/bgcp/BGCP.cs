﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace bgcp
{
    public class BGCP
    {
        private DirectoryInfo _directory;
        private int? _number;
        private DirectoryInfo _result;

        public void InitBGCP(string[] args)
        {
            if (args.Length != 3)
            {
                throw new Exception("No parameters were passed");
            }

            InitNumber(args[1]);
            InitDirectory(args[0]);
            InitResult(args[2]);
        }

        public void InitNumber(string number)
        {
            int n = -1;
            if (!int.TryParse(number, out n))
            {
                throw new Exception("N parameter is invalid. Please use positive, non-zero number");
            }
            if (n <= 0)
            {
                throw new Exception("N parameter is invalid. Please use positive, non-zero number");
            }
            this._number = n;
        }

        public void InitDirectory(string directory)
        {
            if (!Directory.Exists(directory))
            {
                throw new Exception("D parameter is invalid. Directory does not exist");
            }

            if (Directory.GetFiles(directory).Length == 0)
            {
                throw new Exception("D parameter is invalid. Directory does not contains any files");
            }

            if(_number == null)
            {
                throw new Exception("Initialization sequence error.");
            }

            if (Directory.GetFiles(directory).Length < _number.Value)
            {
                throw new Exception("D parameter is invalid. Directory does not contains enough files");
            }

            _directory = new DirectoryInfo(directory);
        }

        public void InitResult(string result)
        {
            if (!Directory.Exists(result))
            {
                throw new Exception("R parameter is invalid. Directory does not exist");
            }

            _result = new DirectoryInfo(result);
        }

        public void BiggestCopy() //add number checks
        {
            if(_directory is null || _number is null || _result is null)
            {
                throw new Exception("Main parameters are uninitialized. Program halted.");
            }
            var files = _directory.GetFiles();
            files = files.OrderByDescending(x => x.Length).ToArray();

            var results = files.Take(_number.Value);

            foreach (var f in results)
            {
                if (File.Exists(Path.Combine(_result.FullName, f.Name)))
                {
                    throw new Exception("File already exist. Program halted.");
                }
            }

            foreach (var f in results)
            {
                using (var input = new FileStream(f.FullName, FileMode.Open))
                {
                    using (var output = new FileStream(Path.Combine(_result.FullName, f.Name), FileMode.Create))
                    {
                        input.CopyTo(output);
                    }
                }
            }
        }
    }
}
