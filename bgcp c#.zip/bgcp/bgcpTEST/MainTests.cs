using NUnit.Framework;

using System;
using System.IO;
using System.Linq;

namespace bgcpTEST
{
    public class Tests
    {
        private bgcp.BGCP bgcp;
        private const uint EXT4_FILE_MAXIMUM = 4294967295;

        [SetUp]
        public void Setup()
        {
            bgcp = new bgcp.BGCP();//new string[3] { @"C:\Users\biost\OneDrive\���������\dolores", "3", @"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS" });
            //RemoveFiles();
        }

        [Test]
        public void InitBGCPTestSuccess()
        {
            Assert.DoesNotThrow(() => 
            {
                bgcp.InitBGCP(new string[3] { @"C:\Users\biost\OneDrive\���������\dolores", "3", @"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS" });
            });
        }

        [Test]
        public void InitBGCPTestNoParameters()
        {
            Assert.Throws<Exception>(() =>
            {
                bgcp.InitBGCP(new string[] { });
            });
        }

        [Test]
        public void InitNumberPositiveNonZero()
        {
            bgcp.InitBGCP(new string[3] { @"C:\Users\biost\OneDrive\���������\dolores", "3", @"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS" });
            Assert.DoesNotThrow(() =>
            {
                bgcp.InitNumber("3");
            });
        }

        [Test]
        public void InitNumberNegativeNonZero()
        {
            bgcp.InitBGCP(new string[3] { @"C:\Users\biost\OneDrive\���������\dolores", "3", @"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS" });
            Assert.Throws<Exception>(() =>
            {
                bgcp.InitNumber("-23");
            });
        }

        [Test]
        public void InitNumberNonNumber()
        {
            bgcp.InitBGCP(new string[3] { @"C:\Users\biost\OneDrive\���������\dolores", "3", @"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS" });
            Assert.Throws<Exception>(() =>
            {
                bgcp.InitNumber("hello");
            });
        }

        [Test]
        public void InitNumberExceedBeyoundEXT4()
        {
            bgcp.InitBGCP(new string[3] { @"C:\Users\biost\OneDrive\���������\dolores", "3", @"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS" });
            Assert.Throws<Exception>(() =>
            {
                unchecked
                {
                    bgcp.InitNumber($"{(EXT4_FILE_MAXIMUM + 1)}");
                }
            });
        }

        [Test]
        public void InitDirectoryExistingDirectory()
        {
            bgcp.InitBGCP(new string[3] { @"C:\Users\biost\OneDrive\���������\dolores", "3", @"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS" });
            Assert.DoesNotThrow(() =>
            {
                bgcp.InitDirectory(@"C:\Users\biost\OneDrive\���������\dolores");
            });
        }

        [Test]
        public void InitDirectorySequenceError()
        {
            bgcp = new bgcp.BGCP();
            Assert.Throws<Exception>(() =>
            {
                bgcp.InitDirectory(@"C:\Users\biost\OneDrive\���������\dolores");
            });
        }

        [Test]
        public void InitDirectoryNonExisting()
        {
            bgcp.InitBGCP(new string[3] { @"C:\Users\biost\OneDrive\���������\dolores", "3", @"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS" });
            Assert.Throws<Exception>(() =>
            {
                bgcp.InitDirectory(@"C:\Users\biost\OneDrive\���������\alvor");
            });
        }

        [Test]
        public void InitResultExistingDirectory()
        {
            bgcp.InitBGCP(new string[3] { @"C:\Users\biost\OneDrive\���������\dolores", "3", @"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS" });
            Assert.DoesNotThrow(() =>
            {
                bgcp.InitResult(@"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS");
            });
        }

        [Test]
        public void InitResultSequenceInterruption()
        {
            bgcp = new bgcp.BGCP();
            Assert.DoesNotThrow(() =>
            {
                bgcp.InitResult(@"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS");
            });
        }

        [Test]
        public void InitResultNonExisting()
        {
            bgcp.InitBGCP(new string[3] { @"C:\Users\biost\OneDrive\���������\dolores", "3", @"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS" });
            Assert.Throws<Exception>(() =>
            {
                bgcp.InitDirectory(@"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTSsssss");
            });
        }

        [Test]
        public void BiggestCopyNormal()
        {
            bgcp.InitBGCP(new string[3] { @"C:\Users\biost\OneDrive\���������\dolores", "3", @"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS" });
            Assert.DoesNotThrow(() =>
            {
                bgcp.BiggestCopy();
            });
            RemoveFiles();
        }

        [Test]
        public void BiggestCopyNonInitializedObject()
        {
            bgcp = new bgcp.BGCP();
            Assert.Throws<Exception>(() =>
            {
                bgcp.BiggestCopy();
            });
            RemoveFiles();
        }

        [Test]
        public void BiggestCopyFileExist()
        {
            bgcp.InitBGCP(new string[3] { @"C:\Users\biost\OneDrive\���������\dolores", "3", @"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS" });
            File.Create(Path.Combine(@"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS", GetTestFile())).Close();
            Assert.Throws<Exception>(() =>
            {
                bgcp.BiggestCopy();
            });
            File.Delete(Path.Combine(@"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS", GetTestFile()));
            RemoveFiles();
        }

        private string GetTestFile()
        {
            DirectoryInfo directory = new DirectoryInfo(@"C:\Users\biost\OneDrive\���������\dolores");
            var files = directory.GetFiles();
            files = files.OrderByDescending(x => x.Length).ToArray();

            var results = files.Take(1).ToList();
            return results[0].Name;
        }

        private void RemoveFiles()
        {
            DirectoryInfo directory = new DirectoryInfo(@"C:\Users\biost\source\repos\bgcp\bgcp\bin\Debug\netcoreapp3.1\RESULTS");
            var files = directory.GetFiles();
            foreach(var f in files)
            {
                f.Delete();
            }
        }
    }
}