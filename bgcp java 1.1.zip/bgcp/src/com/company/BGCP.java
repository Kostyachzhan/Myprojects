package com.company;
import javax.naming.InvalidNameException;
import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class BGCP {
    private String _directory;
    private Integer _number;
    private String _result;

    public void InitBGCP(String[] args)
    {
        if (args.length != 3)
        {
            throw new IllegalArgumentException("No parameters were passed");
        }

        InitNumber(args[1]);
        InitDirectory(args[0]);
        InitResult(args[2]);
    }

    public void InitNumber(String number)
    {
        Integer n = Integer.parseInt(number);
        if (n == null)
        {
            throw new IllegalArgumentException("N parameter is invalid. Please use positive, non-zero number");
        }
        if (n <= 0)
        {
            throw new IllegalArgumentException("N parameter is invalid. Please use positive, non-zero number");
        }
        this._number = n;
    }

    public void InitDirectory(String directory)
    {
        java.nio.file.Path dpath = Paths.get(directory);
        if(!Files.exists(dpath)) {
            throw new IllegalArgumentException("D parameter is invalid. Directory does not exist");
        }
        if (!Files.isDirectory(dpath))
        {
            throw new IllegalArgumentException("D parameter is invalid. Directory does not exist");
        }

        if (new File(directory).list().length == 0)
        {
            throw new IllegalArgumentException("D parameter is invalid. Directory does not contains any files");
        }

        if(_number == null)
        {
            throw new RuntimeException("Initialization sequence error.");
        }

        if (new File(directory).list().length < _number)
        {
            throw new IllegalArgumentException("D parameter is invalid. Directory does not contains enough files");
        }

        _directory = directory;
    }

    public void InitResult(String result)
    {
        java.nio.file.Path rpath = Paths.get(result);
        if(Files.notExists(rpath)) {
            throw new IllegalArgumentException("R parameter is invalid. Directory does not exist");
        }
        if (!Files.isDirectory(rpath))
        {
            throw new IllegalArgumentException("R parameter is invalid. Directory does not exist");
        }

        _result = result;
    }

    public static <K,V extends Comparable<? super V>>
    List<Map.Entry<K, V>> entriesSortedByValues(Map<K,V> map) {

        List<Map.Entry<K,V>> sortedEntries = new ArrayList<Map.Entry<K,V>>(map.entrySet());

        Collections.sort(sortedEntries,
                new Comparator<Map.Entry<K,V>>() {
                    @Override
                    public int compare(Map.Entry<K,V> e1, Map.Entry<K,V> e2) {
                        return e2.getValue().compareTo(e1.getValue());
                    }
                }
        );

        return sortedEntries;
    }

    public void BiggestCopy()
    {
        if(_directory == null || _number == null || _result == null)
        {
            throw new RuntimeException("Main parameters are uninitialized. Program halted.");
        }
        java.nio.file.Path directory_path = Paths.get(_directory);
        Map<Path, Long> files = new HashMap<>();

        try {
            DirectoryStream<Path> stream = Files.newDirectoryStream(directory_path);
            for(Path file: stream) {
                files.put(file, Files.size(file));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        var fl = entriesSortedByValues(files);

        ArrayList<Path> results = new ArrayList<>();
        for(int i = 0; i < _number; ++i) {
            results.add(fl.get(i).getKey());
        }

        for(Path f: results)
        {
            Path result = Paths.get(_result);
            Path path = Paths.get(result.toFile().getPath()+"/"+f.toFile().getName()); //check
            if (Files.exists(path))
            {
                throw new RuntimeException("File already exist. Program halted.");
            }
        }

        for(Path f: results)
        {
            Path result = Paths.get(_result);
            Path path = Paths.get(result.toFile().getPath()+"/"+f.toFile().getName()); //check
            try {
                Files.copy(f, path);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
