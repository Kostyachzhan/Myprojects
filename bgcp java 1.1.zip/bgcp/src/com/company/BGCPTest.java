package com.company;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.function.ThrowingRunnable;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class BGCPTest {

    private BGCP bgcp;

    @Before
    public void setup() {
        bgcp = new BGCP();
        bgcp.InitBGCP(new String[] { "C:\\Users\\biost\\OneDrive\\Документы\\dolores", "3", "C:\\Users\\biost\\source\\repos\\bgcp\\bgcp\\bin\\Debug\\netcoreapp3.1\\RESULTS" });
    }

    @Test(expected = Test.None.class)
    public void InitBGCPTestSuccess()
    {
        bgcp.InitBGCP(new String[] { "C:\\Users\\biost\\OneDrive\\Документы\\dolores", "3", "C:\\Users\\biost\\source\\repos\\bgcp\\bgcp\\bin\\Debug\\netcoreapp3.1\\RESULTS" });
    }

    @Test
    public void InitBGCPTestNoParameters()
    {
        Assert.assertThrows(IllegalArgumentException.class, new ThrowingRunnable() {
            @Override
            public void run() throws Throwable {
                bgcp.InitBGCP(new String[] { });
            }
        });
    }

    @Test(expected = Test.None.class)
    public void InitNumberPositiveNonZero()
    {
        bgcp.InitNumber("3");
    }

    @Test
    public void InitNumberNegativeNonZero()
    {
        Assert.assertThrows(IllegalArgumentException.class, new ThrowingRunnable() {
            @Override
            public void run() throws Throwable {
                bgcp.InitNumber("-23");
            }
        });
    }

    @Test
    public void InitNumberNonNumber()
    {
        Assert.assertThrows(IllegalArgumentException.class, new ThrowingRunnable() {
            @Override
            public void run() throws Throwable {
                bgcp.InitNumber("hello");
            }
        });
    }

    @Test(expected = Test.None.class)
    public void InitDirectoryExistingDirectory()
    {
        bgcp.InitDirectory("C:\\Users\\biost\\OneDrive\\Документы\\dolores");
    }

    @Test
    public void InitDirectorySequenceError()
    {
        bgcp = new BGCP();
        Assert.assertThrows(RuntimeException.class, new ThrowingRunnable() {
            @Override
            public void run() throws Throwable {
                bgcp.InitDirectory("C:\\Users\\biost\\OneDrive\\Документы\\dolores");
            }
        });
    }

    @Test
    public void InitDirectoryNonExisting()
    {
        Assert.assertThrows(IllegalArgumentException.class, new ThrowingRunnable() {
            @Override
            public void run() throws Throwable {
                bgcp.InitDirectory("C:\\Users\\biost\\OneDrive\\Документы\\alvor");
            }
        });
    }

    @Test(expected = Test.None.class)
    public void InitResultExistingDirectory()
    {
        bgcp.InitResult("C:\\Users\\biost\\source\\repos\\bgcp\\bgcp\\bin\\Debug\\netcoreapp3.1\\RESULTS");
    }

    @Test(expected = Test.None.class)
    public void InitResultSequenceInterruption()
    {
        bgcp = new BGCP();
        bgcp.InitResult("C:\\Users\\biost\\source\\repos\\bgcp\\bgcp\\bin\\Debug\\netcoreapp3.1\\RESULTS");
    }

    @Test
    public void InitResultNonExisting()
    {
        Assert.assertThrows(IllegalArgumentException.class, new ThrowingRunnable() {
            @Override
            public void run() throws Throwable {
                bgcp.InitResult("C:\\Users\\biost\\source\\repos\\bgcp\\bgcp\\bin\\Debug\\netcoreapp3.1\\RESULTSsssss");
            }
        });
    }

    @Test(expected = Test.None.class)
    public void BiggestCopyNormal()
    {
        bgcp.BiggestCopy();
        RemoveFiles();
    }

    @Test
    public void BiggestCopyNonInitializedObject()
    {
        bgcp = new BGCP();
        Assert.assertThrows(RuntimeException.class, new ThrowingRunnable() {
            @Override
            public void run() throws Throwable {
                bgcp.BiggestCopy();
            }
        });
        RemoveFiles();
    }

    @Test
    public void BiggestCopyFileExist()
    {
        Path filePath = Paths.get("C:\\Users\\biost\\source\\repos\\bgcp\\bgcp\\bin\\Debug\\netcoreapp3.1\\RESULTS" + "\\" + GetTestFile().getFileName());
        try {
            Files.createFile(filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Assert.assertThrows(RuntimeException.class, new ThrowingRunnable() {
            @Override
            public void run() throws Throwable {
                bgcp.BiggestCopy();
            }
        });
        try {
            Files.delete(filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
        RemoveFiles();
    }

    private Path GetTestFile()
    {
        java.nio.file.Path directory_path = Paths.get("C:\\Users\\biost\\OneDrive\\Документы\\dolores");
        Map<Path, Long> files = new HashMap<>();

        try {
            DirectoryStream<Path> stream = Files.newDirectoryStream(directory_path);
            for(Path file: stream) {
                files.put(file, Files.size(file));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        var fl = BGCP.entriesSortedByValues(files);

        var results = fl.get(0);
        return results.getKey();
    }

    private void RemoveFiles()
    {
        java.nio.file.Path directory_path = Paths.get("C:\\Users\\biost\\source\\repos\\bgcp\\bgcp\\bin\\Debug\\netcoreapp3.1\\RESULTS");
        ArrayList<Path> files = new ArrayList<>();

        try {
            DirectoryStream<Path> stream = Files.newDirectoryStream(directory_path);
            for(Path file: stream) {
                files.add(file);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (Path file: files) {
            try {
                Files.delete(file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}