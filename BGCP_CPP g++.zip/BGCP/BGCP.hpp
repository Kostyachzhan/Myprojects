#ifndef BGCP_H
#define BGCP_H
#include <iostream>
#include <fstream>
#include <filesystem>
#include <string>
#include <map>
#include <vector>
using namespace std;
namespace fs = std::filesystem;

class BGCP {
    private:
        int number;
        string directory;
        string result;
        std::size_t NumOfFilesInDir(fs::path path);
    public:
        BGCP();
        void InitBGCP(int argc, char* argv[]);
        void InitNumber(string num);
        void InitDirectory(string dir);
        void InitResult(string res);
        void BiggestCopy();
};
#endif