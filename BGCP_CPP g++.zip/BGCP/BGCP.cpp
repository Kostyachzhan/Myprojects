#include "BGCP.hpp"
#include <vector>
#include <map>
#include <filesystem>
#include <set>
using namespace std;
namespace fs = std::filesystem;

BGCP::BGCP(){
    number = -1;
    directory = "";
    result = "";
}

void BGCP::InitBGCP(int argc, char* argv[]) {
    if(argc != 4) {
        throw std::invalid_argument("No parameters were passed");
    }
    InitNumber(argv[2]);
    InitDirectory(argv[1]);
    InitResult(argv[3]);
}

std::size_t BGCP::NumOfFilesInDir(fs::path path) {
    using fs::directory_iterator;
    return std::distance(directory_iterator(path), directory_iterator {});
}

void BGCP::InitNumber(string num) {
    try {
        number = std::stoi(num);
    }
    catch (...) {
        throw std::invalid_argument("N parameter is invalid. Please use positive, non-zero number");
    }

    if(number <= 0) {
        throw std::invalid_argument("N parameter is invalid. Please use positive, non-zero number");
    }
}

void BGCP::InitDirectory(string dir) {
    if(!fs::exists(dir) || !fs::is_directory(dir)) {
        throw std::invalid_argument("D parameter is invalid. Directory does not exist");
    }
    if(fs::is_empty(dir)) {
        throw std::invalid_argument("D parameter is invalid. Directory does not contains any files");
    }
    if(NumOfFilesInDir(dir) < number) {
        throw std::invalid_argument("D parameter is invalid. Directory does not contains enough files");
    }
    directory = dir;
}

void BGCP::InitResult(string res) {
    if(!fs::exists(res) || !fs::is_directory(res)) {
        throw std::invalid_argument("R parameter is invalid. Directory does not exist");
    }
    result = res;
}

struct comp {
    template <typename T>

    bool operator()(const T& l, const T& r) const {
        if(l.second != r.second) {
            return l.second > r.second;
        }
        return l.first > r.first;
    }
};

vector<fs::path> sort(map<fs::path, uintmax_t>& m) {
    set<pair<fs::path, uintmax_t>, comp> S(m.begin(), m.end());

    vector<fs::path> res;
    for(auto& it: S) {
        res.push_back(it.first);
    }
    return res;
}

void BGCP::BiggestCopy() {
    if(directory == "" || number == -1 || result == "") {
        throw std::runtime_error("Main parameters are uninitialized. Program halted.");
    }
    map<fs::path, uintmax_t> files;
    for(const auto& entry : fs::directory_iterator(directory)) {
        if(!fs::is_directory(entry.path())) {
            files[entry.path()] = fs::file_size(entry.path());
        }
    }

    vector<fs::path> results;
    auto tmp = sort(files);
    int current = 0;
    //for(iter = files.begin(); iter != files.end(); ++iter) {
    for(auto& value: tmp) {
        if(current < number) {
            //results.push_back((*iter).first);
            results.push_back(value);
        }
        current++;
    }

    for(auto& value: results) {
        string tres = "";
        tres.append(result);
        tres.append("/");
        tres.append(value.filename());
        fs::path res_file(tres);
        if(fs::exists(res_file)) {
            throw std::runtime_error("File already exist. Program halted.");
        }
    }

    for(auto& value: results) {
        string tres = "";
        tres.append(result);
        tres.append("/");
        tres.append(value.filename());
        fs::path res_file(tres);
        fs::copy(value, res_file);
    }
}