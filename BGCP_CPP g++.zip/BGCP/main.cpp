#include <iostream>
#include <stdexcept>
#include "BGCP.hpp"
using namespace std;

int main(int argc, char* argv[]) {
    if(argc != 4) {
        throw std::invalid_argument("No parameters were passed");
    }
    BGCP bgcp;
    bgcp.InitBGCP(argc, argv);
    bgcp.BiggestCopy();
    return 0;
}