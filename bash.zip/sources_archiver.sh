#!/bin/bash

d=$1
r=$2

declare -a files_results
for entry in `ls -R $d | awk '
/:$/&&f{s=$0;f=0}
/:$/&&!f{sub(/:$/,"");s=$0;f=1;next}
NF&&f{ print s"/"$0 }'`; do
	if [ ${entry: -2} == ".c" ] || [ ${entry: -2} == ".h" ]; then
    	files_results+=($entry)
	fi
done

for file in "${files_results[@]}"; do
	tar rvf sources.tar $file
done
gzip -q sources.tar sources.tar.gz

gunzip sources.tar.gz
touch foo.c
touch bar.c
tar rvf sources.tar foo.c
tar rvf sources.tar bar.c
gzip -q sources.tar sources.tar.gz

rm foo.c
rm bar.c

tar xvzf sources.tar.gz -C $r