#!/bin/bash
d=$1
n=$2
r=$3

declare -a files_results
declare -A files_sizes
for entry in `ls $d`; do
    files_results+=($entry)
done

for i in "${files_results[@]}"; do
    key=$d"/"$i
    value=`stat -c %s $key`
    files_sizes+=([$key]=$value)
done

declare -a prev_keys
for ((i=0;i<$n;i++)); do
    min=0
    key=""
    for file in "${!files_sizes[@]}"; do
		val=0
		for pkey in "${prev_keys[@]}"; do
        	if [ "$pkey" == "$file" ]; then
            	val=1
        	fi
    	done
        if (("${files_sizes[$file]}" > "$min")) && [ "$val" == "0" ]; then
            min=${files_sizes[$file]}
            key=$file
        fi
    done
    prev_keys+=($key)
done

for i in "${prev_keys[@]}"; do
    cp $i $r 
done